# Demo roadmap

The current [GpuUiGallery](../examples/GpuUiGallery/README.md) is the Olive-dark
whole-UI showcase, with live ring metrics, cache chart, inspector, owned GPU
dialogs, browser/pickers, text and image/compute laboratory.

GpuSurfaceDemo remains the embedded-surface example; RendererShowcase provides
software/GPU comparison. Three small public-API tutorials remain. Duplicate
bring-up apps were retired; deterministic regression coverage remains.

Precompiled shader/compute programs and direct GPU images are implemented.
Async streaming, broader bindings, OCIO/video and WebGPU/Metal hosts remain
separate work. See [compute](VULKAN_COMPUTE.md), [release](RELEASE_CANDIDATE.md)
and [backend roadmap](BACKEND_ROADMAP.md).
